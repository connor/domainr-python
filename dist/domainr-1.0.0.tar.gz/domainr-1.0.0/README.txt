domainr.py v0.1

See: http://domai.nr/api/docs/json
